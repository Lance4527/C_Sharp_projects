﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project7
{
    public partial class count_avg_form : Form
    {
        public count_avg_form()
        {
            InitializeComponent();
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void clear_button_Click(object sender, EventArgs e)
        {
            user_text.Text = "";
        }

        private void count_button_Click(object sender, EventArgs e)
        {
            string[] words_split = user_text.Text.Split(null);
            double total_words = words_split.Length;
            int total_letters = 0;
            foreach(string word in words_split)
            {
                total_letters += word.Length;
            }
            double letter_avg = (total_letters / total_words);
            MessageBox.Show("There are " + words_split.Length + " words and" +
                " the average number of letter per word is " + letter_avg.ToString("n2"));
        }
    }
}
